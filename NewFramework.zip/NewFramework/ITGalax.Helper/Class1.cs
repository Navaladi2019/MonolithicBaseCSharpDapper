﻿using System;

namespace ITGalax.Helper
{
    public class Class1
    {
    }
}
