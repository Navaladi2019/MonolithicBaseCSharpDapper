﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ITGalax.BaseObject
{
    public   class InfoMessage
    {
        public string Code { get; set; }

        public string Message { get; set; }
    }
}
