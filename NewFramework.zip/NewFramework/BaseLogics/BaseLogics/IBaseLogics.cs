﻿using ITGalax.BaseObject;
using System;
using System.Collections.Generic;
using System.Text;

namespace ITGalax.BaseLogics
{
   public interface IBaseLogics
    {
        public DoBase idoBase { get; set; }


        public DoBase Save();


        public DoBase Delete();


        public  DoBase Open();


         
    }
}
