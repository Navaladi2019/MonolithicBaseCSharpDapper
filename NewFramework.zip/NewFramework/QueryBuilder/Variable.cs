namespace SqlKata
{
    public class Variable
    {
        public string Name { get; set; }

        public Variable(string name)
        {
            this.Name = name;
        }

    }
}