﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ITGalax.QueryGenerator
{
   public static class HubSemExtension
    {

    }
}
