﻿using System;

using DbPooling;
using ITGalax.BaseLogics;
using ITGalax.QueryGenerator;

namespace Tests
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            SqlResult sqlResult = QueryAdapter.GetSql("Audits").Where("TableName", "Test").Compile();

            var a = ITGalax.DataBase.DataAccess.Query(sqlResult);

            Console.ReadLine();

        }
    }
}
