﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Collections.Specialized;
using System.Collections;

namespace UnitOfWorkCore
{
  public static  class Helper
    {
        public static bool HasProperty(this Type obj, string propertyName)
        {
            return obj.GetProperty(propertyName) != null;
        }

        //private static DbContextOptions<testdbContext> GetOptions(string connectionString)
        //{
        //    return (DbContextOptions<testdbContext>)SqlServerDbContextOptionsExtensions.UseSqlServer(new DbContextOptionsBuilder(), connectionString).Options;
        //}

       

      

          

    }
}
