﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UnitOfWorkCore
{
  internal  class OpenLookUpCombo
    {
        public int? LookUpId { get; set; }

        public string ColumnName { get; set; }

        public string Const { get; set; }

        public int listIndex { get; set; }
    }
}
