﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UnitOfWorkCore
{
  public  interface IblBase<T> where T : class
    {
        T Save();
        T Update();
        bool Delete();
    }
}
