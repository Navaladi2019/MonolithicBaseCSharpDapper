﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using System.Reflection;
using Utility;
using Models.Models;

namespace UnitOfWorkCore
{
    public class blBase<T,Tbus> where T : class
    {
        private  DbContext context ;
        public T EntityModel;
        public IUnitOfWork uow;
        private DbSet<T> dbset;
        public Tbus bus;
        protected UserInfo userInfo;



        public blBase(IUnitOfWork uow, Tbus bus)
        {
            this.EntityModel = bus as T;
            this.uow = uow;
            this.bus = bus;
            context = uow.GetDbContext();
            userInfo = uow.GetUserInfo();
        }


        public  void AddLookUpValueToBusList( List<T> listModel,List<Tbus>listbus)
        {
            List<int?> lookupids = new List<int?>();
            List<OpenLookUpCombo> ilstOpenLookUpCombo = new List<OpenLookUpCombo>();

            Dictionary<long, string> dictlook = new Dictionary<long, string>();
            int index = 0;
            foreach (var Model in listModel)
            {
                Tbus bus = (Tbus)Activator.CreateInstance(typeof(Tbus));
                listbus.Add(bus);
                SetModelToBus(Model, bus);

                PropertyInfo[] propertyInfos = bus.GetType().GetProperties();

                foreach (PropertyInfo property in propertyInfos)
                {

                    if (property.Name.Contains("Description") &&
                        (property.GetCustomAttributesData().Where(x => x.AttributeType.Name == "LookUpAttribute").Any()))
                    {
                        string IdColumnName = property.Name.Substring(0, property.Name.Length - 11) + "Id";
                        string ValueColumnName = property.Name.Substring(0, property.Name.Length - 11) + "Const";

                        if (typeof(T).HasProperty(IdColumnName) && typeof(T).HasProperty(ValueColumnName))
                        {
                            string lookupValue = bus.GetType().GetProperty(ValueColumnName).GetValue(bus) as string;
                            int? strlookUpId = (int?)bus.GetType().GetProperty(IdColumnName).GetValue(bus);

                            if (strlookUpId != null && strlookUpId != 0)
                            {

                                if (!lookupids.Contains(strlookUpId))
                                {
                                    lookupids.Add(strlookUpId);
                                    // dictlook.Add((long)lookupId, lookupValue);
                                }

                                ilstOpenLookUpCombo.Add(new OpenLookUpCombo { ColumnName = property.Name, Const = lookupValue, LookUpId = strlookUpId, listIndex = index });

                            }

                        }

                    }

                }

                index++;
            }



            if (lookupids.Count > 0)
            {

                var lookTable = uow.GetReadRepository<LookUpValue>().GetAll().Where(x => lookupids.Contains(x.LookUpId));

                if (lookTable != null && ilstOpenLookUpCombo != null)
                    {
                        foreach (var obj in ilstOpenLookUpCombo)
                        {
                            string desc = obj.ColumnName;
                        var LookUpValue = lookTable.FirstOrDefault(x => x.LookUpId == obj.LookUpId && x.LookUpConst == obj.Const);
                            if (LookUpValue != null)
                            {
                            listbus[obj.listIndex].GetType().GetProperty(desc).SetValue(listbus[obj.listIndex], LookUpValue.LookUpDescription);

                            }

                        }
                    }

                
            }


        }

        public Tbus Open(long Id)
        {
            EntityModel =  uow.GetReadRepository<T>().GetById(Id);
            if(EntityModel != null)
            {
                SetModelToBusWithLookUp(EntityModel, bus);

            }
            else
            {
                List<string> AddErrmsg = new List<string>();
                AddErrmsg.Add("No Record Found.");
                EntityModel.GetType().GetProperty("ilstErrMsg").SetValue(EntityModel, AddErrmsg);
            }
            return bus;
        }
        internal T openmodel(long id)
        {
           return uow.GetReadRepository<T>().GetById(id);
        }

        internal void setParentToChild()
        {
            PropertyInfo[] propertyInfos = bus.GetType().GetProperties();

            foreach (PropertyInfo property in propertyInfos)
            {
                if (typeof(T).HasProperty(property.Name))
                {
                    property.SetValue(bus, EntityModel.GetType().GetProperty(property.Name).GetValue(EntityModel));
                }
            }
        }


    

        /// <summary>
        /// Sets Model Obj to Bus Obj
        /// </summary>
        /// <param name="Model"></param>
        /// <param name="Bus"></param>
        public void SetModelToBus(T Model, Tbus Bus)
        {
            if((Model != null) && (Bus != null))
            {
                PropertyInfo[] propertyInfos = Bus.GetType().GetProperties();

                foreach (PropertyInfo property in propertyInfos)
                {
                    if (typeof(T).HasProperty(property.Name))
                    {
                        property.SetValue(Bus, Model.GetType().GetProperty(property.Name).GetValue(Model));
                    }
                }
            }
            
        }



        /// <summary>
        /// Sets Model Obj to Bus Obj with LookUp Values
        /// </summary>
        /// <param name="EntityModel"></param>
        /// <param name="tbus"></param>
        public void SetModelToBusWithLookUp(T EntityModel, Tbus tbus)
        {
            string DescriptionFormat = "Description";
            List<int?> lookupids = new List<int?>();
            Dictionary<string, string> dictlook = new Dictionary<string, string>();
            List<OpenLookUpCombo> ilstOpenLookUpCombo = new List<OpenLookUpCombo>();
            PropertyInfo[] propertyInfos = tbus.GetType().GetProperties();

            foreach(PropertyInfo property in propertyInfos)
            {
               // var a = property.GetCustomAttributesData();
                    
                    //.Where(x => x.AttributeType.Name == "LooKUp");
                if (property.Name.Contains(DescriptionFormat)  &&
                    (property.GetCustomAttributesData().Where(x=>x.AttributeType.Name == "LookUpAttribute").Any()))
                {
                    string IdColumnName = property.Name.Substring(0,property.Name.Length - 11) + "Id";
                    string ValueColumnName = property.Name.Substring(0,property.Name.Length - 11) + "Const";

                  if(typeof(T).HasProperty(IdColumnName) && typeof(T).HasProperty(ValueColumnName))
                    {
                        string lookupValue = EntityModel.GetType().GetProperty(ValueColumnName).GetValue(EntityModel) as string;
                        int? strlookUpId = (int?)EntityModel.GetType().GetProperty(IdColumnName).GetValue(EntityModel);
                        if (strlookUpId != null)
                        {
                         
                            if(strlookUpId != 0)
                            {
                                if(!lookupids.Where(x=>x.Value == strlookUpId).Any())
                                {
                                    lookupids.Add(strlookUpId);
                                }
                               
                                //dictlook.Add(strlookUpId, lookupValue);
                                ilstOpenLookUpCombo.Add(new OpenLookUpCombo { ColumnName = property.Name, Const = lookupValue, LookUpId = strlookUpId });
                            }
                        }

                      //  property.SetValue(tbus, uow.GetDbContext().Set<LookUp>().Where(x => x.LookUpId == lookupId && x.LookUpValue == lookupValue).FirstOrDefault().LookUpDescription);
                    }

                }
                else
                {
                    if (typeof(T).HasProperty(property.Name))
                    {
                        property.SetValue(tbus, EntityModel.GetType().GetProperty(property.Name).GetValue(EntityModel));
                    }
                }
            }

            if(lookupids.Count > 0)
            {


                var lookUpTable = uow.GetReadRepository<LookUpValue>().GetAll().Where(x => lookupids.Contains(x.LookUpId));
                foreach (var obj in ilstOpenLookUpCombo)
                {
                
                    var LookUpValue = lookUpTable.FirstOrDefault(x => x.LookUpId == obj.LookUpId && x.LookUpConst == obj.Const);
                    if (LookUpValue != null)
                    {
                        tbus.GetType().GetProperty(obj.ColumnName).SetValue(tbus, LookUpValue.LookUpDescription);
                    }
                   
            }
            }
           
        }
        
        private T GetOldValues()
        {
            var typeInfo = typeof(T).GetTypeInfo();
            var key = this.context.Model.FindEntityType(typeInfo).FindPrimaryKey().Properties.FirstOrDefault();
            var property = typeInfo.GetProperty(key?.Name);
            long PK  = (Convert.ToInt64(property.GetValue(EntityModel)));
            return openmodel(PK);
            
        }
        
        private void SetAuditColumnForUpdate(T entityUpdate, T EntityModel)
        {
            EntityModel.GetType().GetProperty("CreatedBy").SetValue(EntityModel,entityUpdate.GetType().GetProperty("CreatedBy").GetValue(entityUpdate));
            EntityModel.GetType().GetProperty("CreatedDate").SetValue(EntityModel,entityUpdate.GetType().GetProperty("CreatedDate").GetValue(entityUpdate));
            EntityModel.GetType().GetProperty("UpdateSeq").SetValue(EntityModel, (Convert.ToInt64(EntityModel.GetType().GetProperty("UpdateSeq").GetValue(EntityModel))+1));
            EntityModel.GetType().GetProperty("ModifiedBy").SetValue(EntityModel,userInfo.UserId);
            EntityModel.GetType().GetProperty("ModifiedDate").SetValue(EntityModel,DateTime.Now);
        }


        public Tbus SoftDelete()
        {
            try
            {

                if(userInfo != null && !string.IsNullOrEmpty(userInfo.UserId) && !string.IsNullOrWhiteSpace(userInfo.UserId))
                {
                    uow.ForceBeginTransaction();
                    BeforeSave();
                    T entityUpdate = GetOldValues();
                    if (Convert.ToInt64(entityUpdate.GetType().GetProperty("UpdateSeq").GetValue(entityUpdate)) == Convert.ToInt64(EntityModel.GetType().GetProperty("UpdateSeq").GetValue(EntityModel)))
                    {
                        SetAuditColumnForUpdate(entityUpdate, EntityModel);
                        EntityModel.GetType().GetProperty("DeletedFlag").SetValue(EntityModel, "Y");

                        context.Entry(entityUpdate).CurrentValues.SetValues(EntityModel);
                        uow.SaveChanges();
                    }
                    else
                    {
                        throw new DbUpdateConcurrencyException();
                    }
                    uow.CommitInternalTransaction();
                    AfterSave();
                    setParentToChild();
                    return bus;
                }
                else
                {
                  
                    throw new Exception("User Info Not Found.");
                }


            }
            catch (DbUpdateConcurrencyException ex)
            {
                uow.RollbackInternalTransaction();
                List<string> AddErrmsg = new List<string>();
                AddErrmsg.Add("Record Might have changed. Please Refresh and Update Again.");
                EntityModel.GetType().GetProperty("ilstErrMsg").SetValue(EntityModel, AddErrmsg);
                setParentToChild();
                return bus;
            }
            catch (Exception ex)
            {
                uow.RollbackInternalTransaction();
                List<string> AddErrmsg = new List<string>();
                AddErrmsg.Add("Unable to Update. Please try Again");
                AddErrmsg.Add(ex.Message);
                EntityModel.GetType().GetProperty("ilstErrMsg").SetValue(EntityModel, AddErrmsg);
                setParentToChild();
                return bus;
            }

        }

        public Tbus update()
        {
            try
            {
           
                if (userInfo != null && !string.IsNullOrEmpty(userInfo.UserId) && !string.IsNullOrWhiteSpace(userInfo.UserId))
                {
                   
                    BeforeSave();
                    this.EntityModel = bus as T;
                    uow.ForceBeginTransaction();
                    T entityUpdate = GetOldValues();

                    if (Convert.ToInt64(entityUpdate.GetType().GetProperty("UpdateSeq").GetValue(entityUpdate)) == Convert.ToInt64(EntityModel.GetType().GetProperty("UpdateSeq").GetValue(EntityModel)))
                    {
                        SetAuditColumnForUpdate(entityUpdate, EntityModel);
                        context.Entry(entityUpdate).CurrentValues.SetValues(EntityModel);
                        uow.SaveChanges();
                    }
                    else
                    {
                        throw new DbUpdateConcurrencyException();
                    }
                    uow.CommitInternalTransaction();
                    List<string> InfoMsg = new List<string>();
                    InfoMsg.Add("Data Updated Successfully");
                    EntityModel.GetType().GetProperty("ilstInfoMsg").SetValue(EntityModel, InfoMsg);
                    setParentToChild();
                    AfterSave();
                    return bus;
                }
                else
                {
                    throw new Exception("User Info Not Found.");
                }
             

            }
            catch (DbUpdateConcurrencyException ex)
            {
                uow.RollbackInternalTransaction();
                List<string> AddErrmsg = new List<string>();
                AddErrmsg.Add("Record Might have changed. Please Refresh and Update Again.");
                EntityModel.GetType().GetProperty("ilstErrMsg").SetValue(EntityModel, AddErrmsg);
                setParentToChild();
                return bus;
            }
            catch (Exception ex)
            {
                uow.RollbackInternalTransaction();
                List<string> AddErrmsg = new List<string>();
                AddErrmsg.Add("Unable to Update. Please try Again");
                AddErrmsg.Add(ex.Message);
                EntityModel.GetType().GetProperty("ilstErrMsg").SetValue(EntityModel, AddErrmsg);
                setParentToChild();
                return bus;
            }



        }

        public Tbus HardDelete()
        {
           try
            {
                this.EntityModel = bus as T;
                if (userInfo != null && !string.IsNullOrEmpty(userInfo.UserId) && !string.IsNullOrWhiteSpace(userInfo.UserId))
                {
                    EntityModel.GetType().GetProperty("ModifiedBy").SetValue(EntityModel, userInfo.UserId);
                    uow.ForceBeginTransaction();
                    uow.GetCrudRepository<T>().Delete(EntityModel);
                    uow.SaveChanges();
                    uow.CommitInternalTransaction();
                    List<string> InfoMsg = new List<string>();
                    InfoMsg.Add("Data Deleted Successfully");
                    EntityModel.GetType().GetProperty("ilstInfoMsg").SetValue(EntityModel, InfoMsg);
                }
                else
                {
                    throw new Exception("User Info Not Found.");
                }
                 

            }
            catch(Exception ex)
            {
                uow.RollbackInternalTransaction();
                List<string> AddErrmsg = new List<string>();
                AddErrmsg.Add("Unable to Delete. Please try Again");
                AddErrmsg.Add(ex.Message);
                EntityModel.GetType().GetProperty("ilstErrMsg").SetValue(EntityModel, AddErrmsg);

            }

            setParentToChild();
            return bus;
        }

        public virtual Tbus BeforeSave()
        {
            return this.bus;
        }

        public virtual Tbus AfterSave()
        {
            return this.bus;
        }



        void SetAuditColumnForInsert(T EntityModel)
        {
            EntityModel.GetType().GetProperty("CreatedBy").SetValue(EntityModel, userInfo.UserId);
            EntityModel.GetType().GetProperty("CreatedDate").SetValue(EntityModel, DateTime.UtcNow);
            EntityModel.GetType().GetProperty("UpdateSeq").SetValue(EntityModel, 0);
            EntityModel.GetType().GetProperty("ModifiedBy").SetValue(EntityModel, userInfo.UserId);
            EntityModel.GetType().GetProperty("ModifiedDate").SetValue(EntityModel, DateTime.UtcNow);
            EntityModel.GetType().GetProperty("DeletedFlag").SetValue(EntityModel, "N");
        }

        public Tbus Save()
        {
           
            try
            {
               
                BeforeSave();
                this.EntityModel = bus as T;
                SetAuditColumnForInsert(EntityModel);
                uow.ForceBeginTransaction();
                uow.GetCrudRepository<T>().Add(EntityModel);
                
                uow.SaveChanges();
                uow.CommitInternalTransaction();
                List<string> InfoMsg = new List<string>();
                InfoMsg.Add("Data Saved Successfully");
                EntityModel.GetType().GetProperty("ilstInfoMsg").SetValue(EntityModel, InfoMsg);
                setParentToChild();
                AfterSave();


            }catch(Exception ex)
            {
                uow.RollbackInternalTransaction();
                List<string> AddErrmsg = new List<string>();
                AddErrmsg.Add("Unable to Save. Please try Again");
                EntityModel.GetType().GetProperty("ilstErrMsg").SetValue(EntityModel, AddErrmsg);
                setParentToChild();
            }

         
            return bus;
        }


       


}

    
}

