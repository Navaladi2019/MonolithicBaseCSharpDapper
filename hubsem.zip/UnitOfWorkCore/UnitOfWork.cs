﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using System;
using System.Collections.Concurrent;
using System.Data;
using Utility;

namespace UnitOfWorkCore
{
    public class UnitOfWork<T> : IUnitOfWork<T> where T : DbContext
    {
      

        public readonly DbContext Context;
        private IDbContextTransaction _transaction;
        public IDbContextTransaction transaction;
        private IsolationLevel? _isolationLevel;
        public UserInfo UserInfo;
        /// <summary>
        /// Holds collection of repositories
        /// </summary>
        private ConcurrentDictionary<string, object> repositories;



        /// <summary>
        /// Returns DbContext to Internal
        /// </summary>
      
         DbContext IUnitOfWork.GetDbContext()
        {
            return Context;
        }

    

        public UnitOfWork(T dbContext, IUserInfo UserInfo)
        {
            Context = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
            this.UserInfo = UserInfo.GetUserInfo();

            //
        }

        public UserInfo GetUserInfo()
        {
            return this.UserInfo;
        }


        ICrudRepository<TEntity> IUnitOfWork.GetCrudRepository<TEntity>() where TEntity : class
        {
            if (this.repositories == null)
            {
                this.repositories = new ConcurrentDictionary<string, object>();
            }

            var type = $"Crud - {typeof(TEntity).Name}";
            if (!this.repositories.ContainsKey(type))
            {
                this.repositories.TryAdd(type, new CrudRepository<TEntity>(Context));
            }

            return this.repositories[type] as ICrudRepository<TEntity>;
        }

        /// <inheritdoc />
        public IReadRepository<TEntity> GetReadRepository<TEntity>() where TEntity : class
        {
            if (this.repositories == null)
            {
                this.repositories = new ConcurrentDictionary<string, object>();
            }

            var type = $"Read - {typeof(TEntity).Name}";
            if (!this.repositories.ContainsKey(type))
            {
                this.repositories.TryAdd(type, new ReadRepository<TEntity>(Context));
            }

            return this.repositories[type] as IReadRepository<TEntity>;
        }

        private void StartNewTransactionIfNeeded()
        {
            if(transaction == null)
            {
                if (_transaction == null)
                {
                    if (_isolationLevel.HasValue)
                        _transaction = Context.Database.BeginTransaction(_isolationLevel.GetValueOrDefault());
                   
                    else
                        _transaction = Context.Database.BeginTransaction();
                }
            }
           
        }


        public void BeginTransaction()
        {
            if (transaction == null)
            {
                if (_isolationLevel.HasValue)
                    transaction = Context.Database.BeginTransaction(_isolationLevel.GetValueOrDefault());
                else
                    transaction = Context.Database.BeginTransaction();
            }
        }

        public void CommitTransaction()
        {
            //do not open transaction here, because if during the request
            //nothing was changed (only select queries were run), we don't
            //want to open and commit an empty transaction - calling SaveChanges()
            //on _transactionProvider will not send any sql to database in such case
            Context.SaveChanges();

            if (transaction != null)
            {
                transaction.Commit();

                transaction.Dispose();
                transaction = null;
            }
        }

        public void RollbackTransaction()
        {
           
                if (transaction == null) return;

                transaction.Rollback();

                transaction.Dispose();
                transaction = null;
            

        }

        public DbSet<Y> Set<Y>() where Y : class
        {
            return Context.Set<Y>();
        }

        public void ForceBeginTransaction()
        {
            StartNewTransactionIfNeeded();
        }

         void IUnitOfWork.CommitInternalTransaction()
        {
            //do not open transaction here, because if during the request
            //nothing was changed (only select queries were run), we don't
            //want to open and commit an empty transaction - calling SaveChanges()
            //on _transactionProvider will not send any sql to database in such case
          //  Context.SaveChanges();

            if (_transaction != null)
            {
                _transaction.Commit();

                _transaction.Dispose();
                _transaction = null;
            }
        }

         void IUnitOfWork.RollbackInternalTransaction()
        {
            if(transaction != null)
            {
                if (_transaction == null) return;

                _transaction.Rollback();

                _transaction.Dispose();
                _transaction = null;
            }
        
        }

         int IUnitOfWork.SaveChanges()
        {
            StartNewTransactionIfNeeded();

            return Context.SaveChanges();
        }

        public void SetIsolationLevel(IsolationLevel isolationLevel)
        {
            _isolationLevel = isolationLevel;
        }

        public void ClearIsolationLevel()
        {
            _isolationLevel = null;
        }

        public void Dispose()
        {
            if (_transaction != null)
                _transaction.Dispose();

            _transaction = null;
        }

      

     
    }
}
