﻿using Microsoft.EntityFrameworkCore;
using System.Data;
using Utility;

namespace UnitOfWorkCore
{
    public interface IUnitOfWork<T> : IUnitOfWork where T : DbContext
    {
    }

    public interface IUnitOfWork
    {


     


        /// <summary>
        /// Get UserInfo
        /// </summary>
        /// <returns></returns>
        UserInfo GetUserInfo();


        /// <summary>
        /// Returns the set of entities of given type
        /// </summary>
       
        public DbSet<T> Set<T>() where T : class;



        /// <summary>
        ///  Get readonly repository for the given database entity type
        /// </summary>
        /// <typeparam name="TEntity">Entity type for which repository required</typeparam>
        /// <returns>Readonly repository object</returns>
       public IReadRepository<TEntity> GetReadRepository<TEntity>() where TEntity : class;

        /// <summary>
        /// Get repository that would allow CRUD operations over the given database entity
        /// </summary>
        /// <typeparam name="TEntity">Entity type for which repository required</typeparam>
        /// <returns>Repository object</returns>
      public  ICrudRepository<TEntity> GetCrudRepository<TEntity>() where TEntity : class;



        /// <summary>
        /// Opens a new transaction instantly when being called.
        /// If a transaction is already open, it won't do anything.
        /// Generally, you shouldn't call this method unless you need
        /// to control the exact moment of opening a transaction.
        /// Unit of Work automatically handles opening transactions
        /// in a convenient time.        
        /// </summary>
        void ForceBeginTransaction();

        /// <summary>
        /// Commits the current transaction (does nothing when none exists).
        /// </summary>
        void CommitInternalTransaction();

        /// <summary>
        /// Rolls back the current transaction (does nothing when none exists).
        /// </summary>
        void RollbackInternalTransaction();

        /// <summary>
        /// Saves changes to database, previously opening a transaction
        /// only when none exists. The transaction is opened with isolation
        /// level set in Unit of Work before calling this method.
        /// </summary>
        int SaveChanges();

        /// <summary>
        /// Sets the isolation level for new transactions.
        /// </summary>
        /// <param name="isolationLevel"></param>
       public void SetIsolationLevel(IsolationLevel isolationLevel);


        /// <summary>
        /// Clears the isolation Level
        /// </summary>
        public void ClearIsolationLevel();


        /// <summary>
        /// Creates Unit Transaction
        /// </summary>

        public void BeginTransaction();


        /// <summary>
        /// Commits Unit Transaction
        /// </summary>

        public void CommitTransaction();



        /// <summary>
        /// Rollback Unit Transaction
        /// </summary>
        public void RollbackTransaction();


        internal DbContext GetDbContext();



     


    }    
}
