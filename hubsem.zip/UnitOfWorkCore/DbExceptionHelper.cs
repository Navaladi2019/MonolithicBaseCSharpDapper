﻿namespace UnitOfWorkCore
{
    public class DbExceptionHelper
    {

    }
}
