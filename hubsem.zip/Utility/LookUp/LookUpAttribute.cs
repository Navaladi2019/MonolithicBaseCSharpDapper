﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UnitOfWorkCore.BlHelper
{

    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class LookUpAttribute : Attribute
    {

    }
}
