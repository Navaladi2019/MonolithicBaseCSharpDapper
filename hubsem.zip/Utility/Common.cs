﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Utility
{
   public static class Common
    {
        public static DateTime? setFromDate(DateTime? FromDate)
        {
            if (FromDate != null && FromDate != DateTime.MinValue)
            {
                FromDate = Convert.ToDateTime(FromDate).Date;
            }
            return FromDate;
        }

        public static DateTime? SetToDate(DateTime? ToDate)
        {
            if (ToDate != null && ToDate != DateTime.MinValue)
            {
                ToDate = Convert.ToDateTime(ToDate).AddDays(1).AddMilliseconds(-1);
            }
            return ToDate;
        }
    }
}
