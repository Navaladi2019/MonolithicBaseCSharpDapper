﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Utility
{
    public abstract class SearchBase
    {

        protected SearchBase()
        {

        }

        public virtual string SearchQuery()
        {
            return null;
        }

        public virtual string OrderBy { get; set; }

        public  int Page {get;set;}

        public  int PageCount { get; set; }

        public virtual string GroupBy()
        {
            return null;
        }
       

    }
}
