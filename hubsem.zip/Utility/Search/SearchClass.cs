﻿using Dapper;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Text;

namespace Utility
{

  

  

   public class SearchClass<TReturn,T>
    {
        public string[] Queries { get; set; }

        public DynamicParameters Parameters { get; set; }

        public IConfiguration Configuration { get; }

      

        public SearchResult<TReturn> Search(T SearchObj,string ConnectionString)
        {

            SearchResult<TReturn> lSearchResult = new SearchResult<TReturn>();

            try
            {

                SearchClass<TReturn, T> searchClass = SearchQuery.GenerateSearchQuery<TReturn, T>(SearchObj);
                if (searchClass != null)
                {
                    string Query = string.Empty;
                    if (searchClass.Queries.Length > 0)
                    {
                        Query = searchClass.Queries[0] + " " + " ;" + searchClass.Queries[1] + " " + ";";
                    }

                    //var builder = new ConfigurationBuilder().Add().ad
                     
                ////        SetBasePath(Directory.GetCurrentDirectory())
                ////.AddJsonFile("appsettings.json");
                //    var configuration = builder.Build();
                    // var ConnectionString = Configuration["DefaultConnection"];
                    using (IDbConnection connection = new SqlConnection("Server=.;Database=testdb;Trusted_Connection=True;"))
                    {
                        connection.Open();
                        var result = connection.QueryMultiple(Query, searchClass.Parameters);

                        var Count = result.Read<CountClass>().AsList();
                        var searchResult = result.Read<TReturn>();

                        lSearchResult.ilstSearchResult = searchResult.AsList();
                        if (Count != null && Count.Count > 0)
                            lSearchResult.TotalCount = Count[0].COUNTS;

                        if (Convert.ToInt32(SearchObj.GetType().GetProperty("Page").GetValue(SearchObj)) == 1)
                        {
                            lSearchResult.IsFirstPage = true;
                        }
                        double pagecount = (double)Convert.ToDecimal(SearchObj.GetType().GetProperty("PageCount").GetValue(SearchObj));
                        lSearchResult.TotalPages = (int)Math.Round((lSearchResult.TotalCount + 5) / pagecount);
                        if (Convert.ToInt32(SearchObj.GetType().GetProperty("Page").GetValue(SearchObj)) == lSearchResult.TotalPages)
                        {
                            lSearchResult.IsLastPage = true;
                        }

                        lSearchResult.Page = Convert.ToInt32(SearchObj.GetType().GetProperty("Page").GetValue(SearchObj));
                        lSearchResult.PageCount = Convert.ToInt32(SearchObj.GetType().GetProperty("PageCount").GetValue(SearchObj));

                    }
                }
                return lSearchResult;


            }
            catch (Exception ex)
            {
                throw ex;
            }
      

        }
    }
}
