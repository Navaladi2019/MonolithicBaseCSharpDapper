﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace Utility
{
   public static class SearchQuery
    {

        public static SearchClass<TReturn, T> GenerateSearchQuery<TReturn,T>(T SearchObj)
        {
          
            string RecordQuery = null;
            string CountQuery = null;
            string[] Queries = new string[2];
            string GroupBy = null;
            DynamicParameters ilstobj = new DynamicParameters();

            SearchClass<TReturn, T> lSearchClass = new SearchClass<TReturn, T>();


            if (SearchObj != null)
            {
                PropertyInfo[] propertyInfos = SearchObj.GetType().GetProperties();

                SearchBase aSearchBase = SearchObj as SearchBase;

                RecordQuery = aSearchBase.SearchQuery();
                GroupBy = aSearchBase.GroupBy();

                    ///SearchObj.GetType().GetProperty("SearchQuery").GetValue(SearchObj) as string;

                int Page = Convert.ToInt32(SearchObj.GetType().GetProperty("Page").GetValue(SearchObj));

                    int PageCount = Convert.ToInt32(SearchObj.GetType().GetProperty("PageCount").GetValue(SearchObj));

                    int offset = (Page * PageCount) - PageCount;
                    int limit = PageCount;

                    string OrderBy = (SearchObj.GetType().GetProperty("OrderBy").GetValue(SearchObj)) as string;
                

                /// Constructing Where Query 
                    int indexWhere = 0;
                    foreach (PropertyInfo property in propertyInfos)
                    {

                    if(property.GetCustomAttributesData().Where(x => x.AttributeType.Name == "SearchAttribute").Any())
                    {

                        bool IsHaving = property.GetCustomAttribute<SearchAttribute>().IsHaving;
                        if (IsHaving == false && (property.GetCustomAttribute<SearchAttribute>().IsGroupBy == false))
                        {
                            if (indexWhere == 0)
                            {
                                RecordQuery = $" {RecordQuery}   WHERE  ";
                            }
                            else
                            {
                                RecordQuery = $" {RecordQuery}   AND  ";
                            }

                            string ColumnName = property.GetCustomAttribute<SearchAttribute>().Param;
                            string Operator = property.GetCustomAttribute<SearchAttribute>().Operator;
                            string ParamAlias = property.GetCustomAttribute<SearchAttribute>().ParamAlias;
                            object value = property.GetValue(SearchObj);
                            RecordQuery = RecordQuery + " " + ColumnName + " " + Operator + " " + "@" + ParamAlias;
                            string ATColumnName = "@" + ParamAlias;
                            ilstobj.Add(ATColumnName, value);
                            indexWhere++;
                        }

                    }
                    }

                    /// Constructing Group By Query
                //int indexGroupBy = 0;
                //foreach (PropertyInfo property in propertyInfos)
                //{
                //    if (property.GetCustomAttributesData().Where(x => x.AttributeType.Name == "SearchAttribute").Any())
                //    {

                //        if (property.GetCustomAttribute<SearchAttribute>().IsGroupBy == true)
                //        {
                //            if (indexWhere == 0)

                //                RecordQuery = $" {RecordQuery}   GroupBy  ";
                //            string ColumnName = property.GetCustomAttribute<SearchAttribute>().ColumnName;

                //            RecordQuery = $" {RecordQuery}   {ColumnName} ";
                //            indexGroupBy++;
                //        }
                //    }
                       
                //}

                if(GroupBy != null)
                {
                    RecordQuery = $" {RecordQuery}   GroupBy  {GroupBy}";
                }

                /// Construcing Having Query
                int indexHaving = 0;
                    foreach (PropertyInfo property in propertyInfos)
                    {
                    if (property.GetCustomAttributesData().Where(x => x.AttributeType.Name == "SearchAttribute").Any())
                    {
                        bool IsHaving = property.GetCustomAttribute<SearchAttribute>().IsHaving;
                        if (IsHaving == true && (property.GetCustomAttribute<SearchAttribute>().IsGroupBy == false))
                        {
                            if (indexHaving == 0)
                            {
                                RecordQuery = $" {RecordQuery}   HAVING  ";
                            }
                            else
                            {
                                RecordQuery = $" {RecordQuery}   AND  ";
                            }
                            string ColumnName = property.GetCustomAttribute<SearchAttribute>().Param;
                            string Operator = property.GetCustomAttribute<SearchAttribute>().Operator;
                            string ParamAlias = property.GetCustomAttribute<SearchAttribute>().ParamAlias;
                            object value = property.GetValue(SearchObj);
                            RecordQuery = RecordQuery + " " + ColumnName + " " + Operator + " " + "@" + ParamAlias;
                            string ATColumnName = "@" + ParamAlias;
                            ilstobj.Add(ATColumnName, value);
                            indexHaving++;
                        }

                    }
                       
                    }

                     /// Construcing Count Query
                     /// 

                    CountQuery = $"SELECT   COUNT(1) AS COUNTS FROM ({RecordQuery}) AS COUNT";

                    /// Constructing Final Select Query

                    RecordQuery = $" {RecordQuery} ORDER BY {OrderBy}  OFFSET {offset}  ROWS FETCH NEXT {limit} ROWS ONLY";

                Queries[0] = CountQuery;

                Queries[1] = RecordQuery;

                lSearchClass.Queries = Queries;
                lSearchClass.Parameters = ilstobj;
              
            }

            return lSearchClass;
        }

    }
}
