﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Utility
{
    public class SearchResult<T>
    {


        public SearchResult()
        {
            ilstSearchResult = new List<T>();
            ilstErrMsg = new List<string>();
            ilstInfoMsg = new List<string>();
        }
        public virtual int Page { get; set; }

        public virtual int PageCount { get; set; }
        public virtual int TotalCount { get; set; }
        public int TotalPages { get; set; }
        public bool IsFirstPage { get; set; }
        public bool IsLastPage { get; set; }
        public List<T> ilstSearchResult { get; set; }
        public List<string> ilstErrMsg { get; set; }


        public List<string> ilstInfoMsg { get; set; }
    }

    public class CountClass
    {
        public int COUNTS { get; set; }
    }
}
