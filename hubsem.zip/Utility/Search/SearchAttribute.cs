﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Utility
{

    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field| AttributeTargets.Enum)]
   public class SearchAttribute : Attribute
    {
        public string Param { get; set; }
        public string Operator { get; set; }
        public bool IsGroupBy { get; set; }
        public bool IsHaving { get; set; }

        public string ParamAlias { get; set; }
    }
}
