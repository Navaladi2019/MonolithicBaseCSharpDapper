﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Utility
{
  public  interface IUserInfo
    {
        void SetUserInfo(UserInfo aUserInfo);

        UserInfo GetUserInfo();
    }
}
