﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Utility
{
  public  class UserInfo : IUserInfo
    {

        //public UserInfo userInfo;
        //public UserInfo()
        //{
        //    userInfo = new UserInfo();
        //}

        public string UserId { get; set; }

        public string UserName { get; set; }
      public  void SetUserInfo(UserInfo aUserInfo)
        {
            this.UserId = aUserInfo.UserId;
            this.UserName = aUserInfo.UserName;
        }

         public UserInfo GetUserInfo()
        {
            return this;
        }

     

    }
}
