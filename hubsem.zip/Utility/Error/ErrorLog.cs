﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading;

namespace Utility
{
    public class ErrorLog
    {
        static ReaderWriterLock locker = new ReaderWriterLock();
        private static ErrorLog errLog = new ErrorLog();
        public static ErrorLog Instance
        {

            get
            {
                return ErrorLog.errLog;
            }
        }



        public bool Write(object ex)
        {

            string errMessage = ex.ToString();
            bool flag = false;


            if (Directory.Exists(Path.Combine(Directory.GetCurrentDirectory(), "Files")))
            {

            }
            else
            {
                Directory.CreateDirectory(Path.Combine(Directory.GetCurrentDirectory(), "Files"));
            }

            if (Directory.Exists(Path.Combine(Directory.GetCurrentDirectory(), "Files", "ErrorLog")))
            {

            }
            else
            {
                Directory.CreateDirectory(Path.Combine(Directory.GetCurrentDirectory(), "Files", "ErrorLog"));
            }



            string file = Path.Combine(Directory.GetCurrentDirectory(), "Files", "ErrorLog", "ErrorLog_" + DateTime.Today.ToString("dd_MM_yyyy") + ".txt");

            try
            {
                locker.AcquireWriterLock(int.MaxValue);
                using (StreamWriter SW = File.AppendText(file))
                {
                    SW.WriteLine("===========================================================");
                    SW.WriteLine("Datetime Stamp : " + DateTime.Now.ToLocalTime());
                    SW.WriteLine(errMessage);
                    flag = true;
                }

            }
            catch (Exception e)
            {
                flag = false;
            }
            finally
            {
                locker.ReleaseLock();

            }
            return flag;

        }
    }
}
