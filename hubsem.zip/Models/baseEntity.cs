﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Models
{
   public abstract class baseEntity
    {
        
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }

        public DateTime ModifiedDate { get; set; }

        [ConcurrencyCheck]
        public long UpdateSeq { get; set; }
        public string DeletedFlag { get; set; }
    }
}
