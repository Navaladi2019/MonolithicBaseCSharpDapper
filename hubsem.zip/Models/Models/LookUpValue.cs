﻿using System;
using System.Collections.Generic;

namespace Models.Models
{
    public partial class LookUpValue : baseEntity
    {
        public long LookUpValueId { get; set; }
        public int LookUpId { get; set; }
        public string LookUpConst { get; set; }
        public string LookUpDescription { get; set; }
       
    }
}
