﻿using System;
using System.Collections.Generic;

namespace Models.Models
{
    public partial class LookUp : baseEntity
    {
        public long LookUpSerialId { get; set; }
        public int LookUpId { get; set; }
        public string LookUpValue { get; set; }
        public string LookUpDescription { get; set; }
       
    }
}
