﻿using System;
using System.Collections.Generic;

namespace Models.Models
{
    public partial class LookUpMetaData : baseEntity
    {
        public long LookUpMetadataId { get; set; }
        public long LookUpValueId { get; set; }
        public string MetaDataName { get; set; }
        public string MetaDataType { get; set; }
        public string MetaDataDescription { get; set; }
       
    }
}
