﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BusinessLogics;
using BusinessObject;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Models.Models;
using UnitOfWorkCore;

namespace Account360.Controllers
{
    [ApiController]
    [Route("[controller]")]
    
    public class WeatherForecastController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        private readonly ILogger<WeatherForecastController> _logger;

        public IUnitOfWork uow;
        public WeatherForecastController(ILogger<WeatherForecastController> logger, IUnitOfWork uow)
        {
            _logger = logger;
            this.uow = uow;
        }
        [HttpPost]

        [AllowAnonymous]
        [Route("getAllLoookUP")]
        public IEnumerable<LookUp> getlookUp()
        {
            busLookUp abuslookup = new busLookUp();
            blLookUp lbllookup = new blLookUp(uow, abuslookup);
            return lbllookup.getall();

        }

        [HttpGet]
        [AllowAnonymous]
        public IEnumerable<WeatherForecast> Get()
        {
            var rng = new Random();
            return Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                Date = DateTime.Now.AddDays(index),
                TemperatureC = rng.Next(-20, 55),
                Summary = Summaries[rng.Next(Summaries.Length)]
            })
            .ToArray();
        }
    }
}
