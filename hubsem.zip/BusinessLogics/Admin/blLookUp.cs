﻿using BusinessObject;
using Models.Models;
using System.Collections.Generic;
using UnitOfWorkCore;

namespace BusinessLogics
{
    public  class blLookUp : blBase<LookUp, busLookUp>
    {

        public IUnitOfWork Uow;
        public busLookUp ibusLookUp { get; set; }
        public blLookUp(IUnitOfWork uow, busLookUp abusLookUp) : base(uow, abusLookUp)
        {
            ibusLookUp = abusLookUp;
            Uow = uow;
        }

        public List<LookUp> getall()
        {
           return (List<LookUp>)Uow.GetCrudRepository<LookUp>().GetAll();

        }
    }
}
