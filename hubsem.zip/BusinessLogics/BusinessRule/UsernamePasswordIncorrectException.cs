﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace BusinessLogics.BusinessRule
{
    public class UsernamePasswordIncorrectException : BusinessRulesException
    {
        private const string message = "Username or password is incorrect";

        public UsernamePasswordIncorrectException() : base(HttpStatusCode.BadRequest, message) { }
    }
}
