﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace BusinessLogics.BusinessRule
{
    public class PasswordIsRequiredException : BusinessRulesException
    {
        private const string message = "Password is required";

        public PasswordIsRequiredException() : base(HttpStatusCode.BadRequest, message) { }
    }
}
