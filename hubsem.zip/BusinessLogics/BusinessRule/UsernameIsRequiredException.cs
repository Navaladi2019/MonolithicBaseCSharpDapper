﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace BusinessLogics.BusinessRule
{
    public class UsernameIsRequiredException : BusinessRulesException
    {
        private const string message = "Username is required";

        public UsernameIsRequiredException() : base(HttpStatusCode.BadRequest, message) { }
    }
}
